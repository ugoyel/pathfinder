# Pathfinder UI

A web front end for a Microsoft Copilot Studio agent, in the style of the Pathfinder screens.

- A chat page with a **"What do you want to do today?"** bar wired to your Copilot agent
- A **sidebar of past conversations** you can search, rename and delete
- An **Okta sign-in page** using Moody's single sign-on
- An **Admin page** where the agent, sign-in and network settings are configured in the browser — no code editing

Built as a single ASP.NET Core 8 project. It opens in Visual Studio Enterprise, runs with F5,
and needs no extensions, no Node.js, and no npm build step.

---

## 1. Open and run it

1. Copy the whole `pathfinder-ui` folder onto your work machine.
2. Double-click **`Pathfinder.sln`** to open it in Visual Studio.
3. Press **F5**.

Visual Studio restores the packages, builds, and opens a browser at `https://localhost:7134`.

The first run uses a **local sign-in** — type any name and email and continue. Nothing is
checked. This exists so you can see the app working before Okta is arranged. The app shows a
yellow warning strip the whole time this mode is on.

If Visual Studio asks to trust a development certificate, say yes. That certificate is what
makes `https://localhost` work.

> **Requirement:** the **ASP.NET and web development** workload in Visual Studio, with the
> .NET 8 SDK. If F5 fails saying the SDK is missing, ask IT to add that workload — it is part
> of Visual Studio, not a separate extension.

---

## 2. Connect your Copilot agent

This is the only step that makes chat actually work.

**In Copilot Studio:**

1. Open your agent.
2. **Publish** it. An unpublished agent refuses every connection.
3. Go to **Channels → Mobile app**.
4. Copy the **Token endpoint** URL. It looks like:

   ```
   https://xxxx.environment.api.powerplatform.com/powervirtualagents/botsbyschema/xxx_myAgent/directline/token?api-version=2022-03-01-preview
   ```

**In Pathfinder:**

5. Click **Admin** in the left sidebar.
6. Paste the URL into **Token endpoint URL**.
7. Click **Save agent settings**.
8. Click **Test connection**.

A green box means it works. A red box tells you what went wrong in plain language — a wrong
URL, an unpublished agent, or a blocked firewall each give a different message.

Now go to **Pathfinder Chat** and ask something.

### If the agent requires users to sign in

Copilot Studio agents set to **"Authenticate with Microsoft"** will reject this app, because
Direct Line cannot pass an Entra ID token through on the user's behalf in this setup. Ask
whoever owns the agent to set authentication to **No authentication** or
**Authenticate manually** under *Settings → Security → Authentication*.

---

## 3. Turn on Okta sign-in

### What to ask your Okta administrator for

Send them this:

> Please create an **OIDC Web Application** in Okta for an internal app called Pathfinder.
>
> - **Sign-in redirect URI:** `https://<the app's address>/authorization-code/callback`
> - **Sign-out redirect URI:** `https://<the app's address>/signout-callback-oidc`
> - **Grant type:** Authorization Code (with PKCE)
> - Please assign the users or groups who should have access.
> - Please send me the **Client ID**, the **Client secret**, and the **Issuer URL**.
> - If we want to control admin access by group, please also add the **groups** claim to the
>   ID token and tell me the group name.

The exact two URIs to give them are printed at the top of the **Admin → Authentication** tab,
worked out from whatever address you are using. Copy them from there.

### Entering the details

On **Admin → Authentication**:

1. **Add your own email address to "Administrator email addresses" first.** Once Okta is on,
   this is the only thing that lets you back into the Admin page. If you skip it, you are
   locked out and have to edit `appsettings.json` by hand to get back in.
2. Set **Sign-in method** to `Okta`.
3. Paste the **Issuer URL**, **Client ID** and **Client secret**.
4. Save.
5. **Restart the app** (stop and start it, or press F5 again in Visual Studio).

Sign-in settings only take effect on restart — the app tells you when a restart is pending.

After the restart, the sign-in page shows a single **Continue with Moody's** button.

### If you lock yourself out

Open `src/Pathfinder.Web/appsettings.json`, set `Auth:Mode` to `"DevBypass"`, save, and
restart. You are an admin again, and can fix the settings from the Admin page.

---

## 4. Everything on the Admin page

| Tab | What it is for |
|---|---|
| **Agent** | The Copilot token endpoint, how long to wait for replies, whether to send the signed-in user's name to the agent, and the **Test connection** button |
| **Authentication** | Okta or Entra ID details, who can open the Admin page, and how long a session lasts |
| **Middleware** | Only needed behind a corporate proxy or an API gateway: proxy address, extra headers such as a gateway subscription key, timeouts and retries |
| **Appearance** | The product name, the opening question, the grey placeholder text, and the starter prompt buttons |

Secrets — the client secret, the Direct Line secret, the gateway key — are encrypted before
they are stored, shown only as dots, and never sent back to the browser. Leaving the dots
alone keeps the current value.

Each tab has a **Reset to file values** button that clears what was saved in the browser and
falls back to `appsettings.json`.

---

## 5. Where things are, if you want to change them

```
pathfinder-ui/
├─ Pathfinder.sln                      ← open this in Visual Studio
├─ Dockerfile                          ← for deploying to Azure Container Apps
└─ src/Pathfinder.Web/
   ├─ appsettings.json                 ← starting values for every setting
   ├─ Program.cs                       ← startup, sign-in wiring, the request pipeline
   ├─ Controllers/
   │  ├─ AccountController.cs          ← sign in, sign out
   │  ├─ AdminController.cs            ← the Admin page
   │  ├─ ChatApiController.cs          ← the JSON API the chat page calls
   │  └─ HomeController.cs             ← chat, dashboard, schema pages
   ├─ Services/
   │  ├─ CopilotClient.cs              ← all the Direct Line traffic to your agent
   │  ├─ ConversationService.cs        ← chat history, and reconnecting stale sessions
   │  ├─ SettingsService.cs            ← reads and writes the admin settings
   │  └─ AppOptions.cs                 ← every setting, with a comment explaining it
   ├─ Views/                           ← the pages (.cshtml)
   └─ wwwroot/
      ├─ css/site.css                  ← all the styling, including the navy colours
      └─ js/chat.js                    ← the chat page behaviour
```

**To change the colours**, edit the block at the top of `wwwroot/css/site.css`. Every navy in
the app comes from those few lines.

**To change the wording**, use Admin → Appearance rather than editing files.

---

## 6. Deploying it

The app runs anywhere ASP.NET Core runs. The screenshot this was modelled on was on Azure
Container Apps, and the included `Dockerfile` targets that.

```bash
az acr build --registry <your-registry> --image pathfinder:latest .
```

Two things matter in production:

1. **Mount a volume at `/data`.** The chat history and the encryption key ring live there.
   Without a volume, a redeploy wipes the history and every saved secret has to be re-entered.
2. **Register the real hostname in Okta.** The redirect URI must match the address people
   actually use, not `localhost`.

For more than a handful of users, switch from SQLite to SQL Server: set `Database:Provider`
to `SqlServer` and put the connection string in `ConnectionStrings:Default`. The tables are
created automatically on first run.

A `/healthz` endpoint is available for container health probes.

---

## 7. How it works, briefly

When you send a message:

1. The browser posts it to this app — not to Microsoft.
2. The app fetches a **Direct Line token** from your Copilot Studio token endpoint.
3. It opens a Direct Line conversation and posts your message to it.
4. It polls for the agent's reply. Agents often answer in several parts, so it keeps
   listening for a moment after the last one before showing the answer.
5. Both sides of the exchange are saved, which is what fills the sidebar.

The Direct Line token never reaches the browser. Neither does any secret. Everything goes
through the server, so an API gateway or proxy can sit in front of the Copilot traffic if
your security team wants one.

---

## 8. Troubleshooting

| What you see | What it usually means |
|---|---|
| Yellow strip: *No agent connected* | The token endpoint has not been saved yet — Admin → Agent |
| Test connection: *404 not found* | The token endpoint has a typo, or the part after `?` was cut off when copying |
| Test connection: *403 refused* | The agent is not published, or its Direct Line channel is off |
| Test connection: *network call failed* | Outbound HTTPS to `directline.botframework.com` is blocked. Give IT that hostname, or set a proxy on Admin → Middleware |
| *The agent did not reply in time* | The agent is doing something slow. Raise the reply timeout on Admin → Agent |
| Okta error about `redirect_uri` | The address registered in Okta does not match the one you are using. Compare against the value shown on Admin → Authentication |
| Signed in but Admin is refused | Your email is not in the administrator list. Another admin can add it, or use the lock-out recovery in section 3 |
