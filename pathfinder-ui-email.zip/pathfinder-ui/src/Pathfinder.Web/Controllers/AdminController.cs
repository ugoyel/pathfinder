using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Pathfinder.Web.Auth;
using Pathfinder.Web.Models;
using Pathfinder.Web.Services;

namespace Pathfinder.Web.Controllers;

/// <summary>
/// Everything an administrator can change without editing a file: which Copilot agent
/// this app talks to, how it reaches the network, how people sign in, and the wording
/// on the chat page.
/// </summary>
[Authorize(Policy = AdminRequirement.PolicyName)]
public class AdminController : Controller
{
    private readonly SettingsService _settings;
    private readonly CopilotClient _agent;
    private readonly ShellFactory _shell;
    private readonly UserContext _users;
    private readonly AuthOptions _activeAuth;
    private readonly ILogger<AdminController> _log;

    public AdminController(
        SettingsService settings, CopilotClient agent, ShellFactory shell,
        UserContext users, AuthOptions activeAuth, ILogger<AdminController> log)
    {
        _settings = settings;
        _agent = agent;
        _shell = shell;
        _users = users;
        _activeAuth = activeAuth;
        _log = log;
    }

    [HttpGet]
    public IActionResult Index()
    {
        var auth = _settings.LoadMasked<AuthOptions>(AuthOptions.Section);

        return View(new AdminViewModel
        {
            Shell = _shell.Build("admin"),
            Agent = _settings.LoadMasked<AgentOptions>(AgentOptions.Section),
            Middleware = _settings.LoadMasked<MiddlewareOptions>(MiddlewareOptions.Section),
            Auth = auth,
            Brand = _settings.Load<BrandOptions>(BrandOptions.Section),
            ActiveAuthMode = _activeAuth.Mode,
            AuthRestartPending = RestartPending(),
            ExpectedRedirectUri = AbsoluteUrl(auth.CallbackPath, "/authorization-code/callback"),
            ExpectedSignOutUri = AbsoluteUrl(auth.SignedOutCallbackPath, "/signout-callback-oidc"),
            StatusMessage = TempData["Status"] as string,
            StatusIsError = TempData["StatusIsError"] as bool? ?? false,
        });
    }

    // ---------------------------------------------------------------- saving

    [HttpPost]
    [ValidateAntiForgeryToken]
    public Task<IActionResult> SaveAgent([FromForm] AgentOptions model)
        => SaveAsync(AgentOptions.Section, model, "agent", "Agent settings saved.");

    [HttpPost]
    [ValidateAntiForgeryToken]
    public Task<IActionResult> SaveMiddleware([FromForm] MiddlewareOptions model)
        => SaveAsync(MiddlewareOptions.Section, model, "middleware", "Middleware settings saved.");

    [HttpPost]
    [ValidateAntiForgeryToken]
    public Task<IActionResult> SaveAuth([FromForm] AuthOptions model)
        => SaveAsync(AuthOptions.Section, model, "auth",
            "Sign-in settings saved. Restart the app for them to take effect.");

    [HttpPost]
    [ValidateAntiForgeryToken]
    public Task<IActionResult> SaveBrand([FromForm] BrandOptions model)
        => SaveAsync(BrandOptions.Section, model, "appearance", "Appearance saved.");

    private async Task<IActionResult> SaveAsync<T>(string section, T model, string tab, string message)
    {
        var user = _users.Current;
        await _settings.SaveAsync(section, model, user?.Email ?? user?.Name);
        _log.LogInformation("{User} updated the {Section} settings.", user?.Email ?? "unknown", section);

        TempData["Status"] = message;
        TempData["StatusIsError"] = false;
        return RedirectToAction(nameof(Index), null, tab);
    }

    /// <summary>Deletes the saved overrides for a section so appsettings.json takes over again.</summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reset(string section, string tab)
    {
        var allowed = new[] { AgentOptions.Section, MiddlewareOptions.Section, AuthOptions.Section, BrandOptions.Section };
        if (!allowed.Contains(section, StringComparer.OrdinalIgnoreCase))
            return BadRequest();

        await _settings.ResetSectionAsync(section);
        _log.LogWarning("{User} reset the {Section} settings to the values in appsettings.json.",
            _users.Current?.Email ?? "unknown", section);

        TempData["Status"] = section + " settings were reset to the values in appsettings.json.";
        TempData["StatusIsError"] = false;
        return RedirectToAction(nameof(Index), null, tab);
    }

    // ---------------------------------------------------------------- diagnostics

    /// <summary>
    /// Runs the real handshake against the agent and reports back, so an admin can tell a
    /// wrong URL from a blocked firewall without reading a log file.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Test(CancellationToken ct)
    {
        var (ok, summary, detail) = await _agent.TestConnectionAsync(ct);
        _log.LogInformation("Connection test by {User}: {Result}", _users.Current?.Email ?? "unknown", ok ? "passed" : "failed");
        return Ok(new { ok, summary, detail });
    }

    // ---------------------------------------------------------------- helpers

    /// <summary>
    /// True when the sign-in settings in the database no longer match what the running
    /// process started with, which means a restart is needed before they take effect.
    /// </summary>
    private bool RestartPending()
    {
        var saved = _settings.Load<AuthOptions>(AuthOptions.Section);

        return !string.Equals(saved.Mode, _activeAuth.Mode, StringComparison.OrdinalIgnoreCase)
            || !string.Equals(saved.Authority, _activeAuth.Authority, StringComparison.Ordinal)
            || !string.Equals(saved.ClientId, _activeAuth.ClientId, StringComparison.Ordinal)
            || !string.Equals(saved.Scopes, _activeAuth.Scopes, StringComparison.Ordinal)
            || !string.Equals(saved.CallbackPath, _activeAuth.CallbackPath, StringComparison.Ordinal);
    }

    /// <summary>Builds the full URL to register in Okta, using the host this request arrived on.</summary>
    private string AbsoluteUrl(string? path, string fallback)
    {
        var relative = string.IsNullOrWhiteSpace(path) ? fallback : path.Trim();
        if (!relative.StartsWith('/')) relative = "/" + relative;
        return $"{Request.Scheme}://{Request.Host}{relative}";
    }
}
