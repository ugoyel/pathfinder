using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pathfinder.Web.Auth;
using Pathfinder.Web.Data;
using Pathfinder.Web.Models;
using Pathfinder.Web.Services;

namespace Pathfinder.Web.Controllers;

[Authorize]
public class HomeController : Controller
{
    private readonly ShellFactory _shell;
    private readonly AppDbContext _db;
    private readonly UserContext _users;

    public HomeController(ShellFactory shell, AppDbContext db, UserContext users)
    {
        _shell = shell;
        _db = db;
        _users = users;
    }

    public IActionResult Index() => RedirectToAction(nameof(Chat));

    /// <summary>
    /// The chat page. An id in the route opens that thread; the page itself loads the
    /// message history and the conversation list from the API once it is on screen.
    /// </summary>
    public IActionResult Chat(Guid? id)
    {
        ViewData["OpenConversationId"] = id?.ToString() ?? "";
        return View(_shell.Build("chat"));
    }

    /// <summary>A person's own usage. Nobody sees anyone else's figures.</summary>
    public async Task<IActionResult> Dashboard()
    {
        var user = _users.Require();

        var conversations = await _db.Conversations
            .AsNoTracking()
            .Where(c => c.UserId == user.Id && !c.IsArchived)
            .Select(c => new
            {
                c.Id,
                c.Title,
                c.UpdatedUtc,
                Sent = c.Messages.Count(m => m.Role == "user"),
                Received = c.Messages.Count(m => m.Role == "assistant"),
            })
            .ToListAsync();

        return View(new DashboardViewModel
        {
            Shell = _shell.Build("dashboard"),
            Conversations = conversations.Count,
            MessagesSent = conversations.Sum(c => c.Sent),
            RepliesReceived = conversations.Sum(c => c.Received),
            LastActivityUtc = conversations.Count == 0 ? null : conversations.Max(c => c.UpdatedUtc),
            Recent = conversations
                .OrderByDescending(c => c.UpdatedUtc)
                .Take(8)
                .Select(c => new DashboardViewModel.RecentItem(c.Id, c.Title, c.UpdatedUtc, c.Sent + c.Received))
                .ToList(),
        });
    }

    public IActionResult DbSchema() => View(_shell.Build("schema"));

    [AllowAnonymous]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public IActionResult Error()
    {
        var feature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
        ViewData["Path"] = feature?.Path ?? "";
        ViewData["RequestId"] = HttpContext.TraceIdentifier;
        return View();
    }
}
