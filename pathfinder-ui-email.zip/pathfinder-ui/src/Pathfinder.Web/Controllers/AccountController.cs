using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Pathfinder.Web.Models;
using Pathfinder.Web.Services;

namespace Pathfinder.Web.Controllers;

[AllowAnonymous]
public class AccountController : Controller
{
    /// <summary>
    /// The settings the OpenID Connect handler was actually built with at startup. The
    /// live values in the database may differ if an admin has saved changes and not yet
    /// restarted, and signing in must follow what the handler is really doing.
    /// </summary>
    private readonly AuthOptions _activeAuth;

    private readonly SettingsService _settings;
    private readonly ILogger<AccountController> _log;

    public AccountController(AuthOptions activeAuth, SettingsService settings, ILogger<AccountController> log)
    {
        _activeAuth = activeAuth;
        _settings = settings;
        _log = log;
    }

    private bool UsesSso => !_activeAuth.Mode.Equals("DevBypass", StringComparison.OrdinalIgnoreCase);

    [HttpGet]
    public IActionResult Login(string? returnUrl = null, string? error = null)
    {
        if (User.Identity?.IsAuthenticated == true && error is null)
            return Redirect(SafeReturnUrl(returnUrl));

        return View(new LoginViewModel
        {
            Brand = _settings.Load<BrandOptions>(BrandOptions.Section),
            Mode = _activeAuth.Mode,
            ReturnUrl = SafeReturnUrl(returnUrl),
            Error = error,
        });
    }

    /// <summary>Hands the browser to Okta (or Entra ID) to authenticate.</summary>
    [HttpGet]
    public IActionResult Begin(string? returnUrl = null)
    {
        if (!UsesSso) return RedirectToAction(nameof(Login), new { returnUrl });

        return Challenge(
            new AuthenticationProperties { RedirectUri = SafeReturnUrl(returnUrl) },
            OpenIdConnectDefaults.AuthenticationScheme);
    }

    /// <summary>
    /// The local sign-in used before Okta is wired up. It proves no identity at all, so it
    /// is refused outright whenever the app is configured for real single sign-on.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Local(string name, string email, string? returnUrl = null)
    {
        if (UsesSso) return NotFound();

        name = string.IsNullOrWhiteSpace(name) ? "Test User" : name.Trim();
        email = string.IsNullOrWhiteSpace(email) ? "test.user@example.com" : email.Trim();

        var claims = new List<Claim>
        {
            new("sub", "local|" + email.ToLowerInvariant()),
            new("name", name),
            new("email", email),
        };

        var identity = new ClaimsIdentity(
            claims, CookieAuthenticationDefaults.AuthenticationScheme, "name", "groups");

        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity),
            new AuthenticationProperties { IsPersistent = true });

        _log.LogInformation("Local sign-in used by {Email}. This mode is for testing only.", email);
        return Redirect(SafeReturnUrl(returnUrl));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        if (UsesSso)
        {
            // Clears the local cookie and then ends the session at Okta, so the next
            // sign-in genuinely re-authenticates rather than silently resuming.
            return SignOut(
                new AuthenticationProperties { RedirectUri = "/" },
                CookieAuthenticationDefaults.AuthenticationScheme,
                OpenIdConnectDefaults.AuthenticationScheme);
        }

        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult Denied()
    {
        Response.StatusCode = StatusCodes.Status403Forbidden;
        return View(new LoginViewModel
        {
            Brand = _settings.Load<BrandOptions>(BrandOptions.Section),
            Mode = _activeAuth.Mode,
        });
    }

    /// <summary>Blocks open-redirect attempts by refusing anything that is not a path on this site.</summary>
    private string SafeReturnUrl(string? returnUrl)
        => !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl) ? returnUrl : "/";
}
