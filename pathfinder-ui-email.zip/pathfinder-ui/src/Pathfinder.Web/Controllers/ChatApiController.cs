using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Pathfinder.Web.Auth;
using Pathfinder.Web.Data;
using Pathfinder.Web.Services;

namespace Pathfinder.Web.Controllers;

/// <summary>
/// The JSON API the chat page talks to. Everything is scoped to the signed-in user:
/// a conversation id from another account simply looks like it does not exist.
/// </summary>
[Authorize]
[ApiController]
[Route("api")]
public class ChatApiController : ControllerBase
{
    private readonly ConversationService _conversations;
    private readonly UserContext _users;

    public ChatApiController(ConversationService conversations, UserContext users)
    {
        _conversations = conversations;
        _users = users;
    }

    // ---------------------------------------------------------------- shapes sent to the browser

    public record ConversationDto(string Id, string Title, DateTime UpdatedUtc);

    public record MessageDto(
        string Id,
        string Role,
        string Text,
        DateTime CreatedUtc,
        bool IsError,
        IReadOnlyList<AgentAttachment> Attachments,
        IReadOnlyList<AgentSuggestion> Suggestions);

    public record ThreadDto(string Id, string Title, IReadOnlyList<MessageDto> Messages);

    public record SendRequest(string? ConversationId, string Text);

    public record SendResponse(string ConversationId, string Title, IReadOnlyList<MessageDto> Messages);

    public record RenameRequest(string Title);

    // ---------------------------------------------------------------- conversations

    [HttpGet("conversations")]
    public async Task<ActionResult<IEnumerable<ConversationDto>>> List()
    {
        var user = _users.Require();
        var conversations = await _conversations.ListAsync(user);
        return Ok(conversations.Select(c => new ConversationDto(c.Id.ToString(), c.Title, c.UpdatedUtc)));
    }

    [HttpGet("conversations/{id:guid}")]
    public async Task<ActionResult<ThreadDto>> Get(Guid id)
    {
        var user = _users.Require();
        var conversation = await _conversations.GetAsync(user, id);
        if (conversation is null) return NotFound();

        return Ok(new ThreadDto(
            conversation.Id.ToString(),
            conversation.Title,
            conversation.Messages.Select(ToDto).ToList()));
    }

    [HttpPost("conversations")]
    public async Task<ActionResult<ConversationDto>> Create()
    {
        var user = _users.Require();
        var conversation = await _conversations.CreateAsync(user);
        return Ok(new ConversationDto(conversation.Id.ToString(), conversation.Title, conversation.UpdatedUtc));
    }

    [HttpPost("conversations/{id:guid}/rename")]
    public async Task<IActionResult> Rename(Guid id, [FromBody] RenameRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Title)) return BadRequest(new { error = "A title is required." });

        var user = _users.Require();
        return await _conversations.RenameAsync(user, id, request.Title) ? NoContent() : NotFound();
    }

    [HttpDelete("conversations/{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var user = _users.Require();
        return await _conversations.DeleteAsync(user, id) ? NoContent() : NotFound();
    }

    // ---------------------------------------------------------------- the chat turn

    [HttpPost("chat")]
    public async Task<ActionResult<SendResponse>> Send([FromBody] SendRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Text))
            return BadRequest(new { error = "Type something first." });

        Guid? conversationId = null;
        if (!string.IsNullOrWhiteSpace(request.ConversationId))
        {
            if (!Guid.TryParse(request.ConversationId, out var parsed))
                return BadRequest(new { error = "That conversation id is not valid." });
            conversationId = parsed;
        }

        var user = _users.Require();

        try
        {
            var (conversation, created) = await _conversations.SendAsync(
                user, conversationId, request.Text.Trim(), ct);

            return Ok(new SendResponse(
                conversation.Id.ToString(),
                conversation.Title,
                created.Select(ToDto).ToList()));
        }
        catch (InvalidOperationException)
        {
            return NotFound(new { error = "That conversation no longer exists." });
        }
    }

    // ---------------------------------------------------------------- mapping

    private static MessageDto ToDto(Message message) => new(
        message.Id.ToString(),
        message.Role,
        message.Text,
        message.CreatedUtc,
        message.IsError,
        Parse<AgentAttachment>(message.AttachmentsJson),
        Parse<AgentSuggestion>(message.SuggestedActionsJson));

    private static IReadOnlyList<T> Parse<T>(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return Array.Empty<T>();
        try
        {
            return JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();
        }
        catch (JsonException)
        {
            // Stored by an older build in a shape this version no longer understands.
            // Dropping the extras is better than failing the whole thread.
            return Array.Empty<T>();
        }
    }
}
