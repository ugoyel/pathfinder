namespace Pathfinder.Web.Services;

/// <summary>
/// How this app talks to the Copilot Studio agent. Edited on Admin -> Agent.
/// </summary>
public class AgentOptions
{
    public const string Section = "Agent";

    /// <summary>"TokenEndpoint" (Copilot Studio) or "DirectLineSecret" (Azure Bot Service).</summary>
    public string Mode { get; set; } = "TokenEndpoint";

    /// <summary>Copilot Studio -> Channels -> Mobile app -> "Token endpoint" URL.</summary>
    public string TokenEndpoint { get; set; } = "";

    /// <summary>Azure Bot Service -> Channels -> Direct Line -> secret key. Stored encrypted.</summary>
    public string DirectLineSecret { get; set; } = "";

    public string DirectLineBaseUrl { get; set; } = "https://directline.botframework.com";

    /// <summary>Name shown above agent replies.</summary>
    public string AgentDisplayName { get; set; } = "Pathfinder";

    /// <summary>Seconds to wait for the agent's reply before giving up.</summary>
    public int ReplyTimeoutSeconds { get; set; } = 90;

    /// <summary>How often to ask Direct Line for new activities.</summary>
    public int PollIntervalMs { get; set; } = 800;

    /// <summary>After the agent's last activity, wait this long for follow-up activities before replying.</summary>
    public int QuietPeriodMs { get; set; } = 1500;

    /// <summary>Copilot Studio agents send their greeting in response to this event.</summary>
    public bool SendStartConversationEvent { get; set; } = true;

    /// <summary>Show the agent's opening greeting as the first message in a new thread.</summary>
    public bool ShowGreeting { get; set; } = false;

    /// <summary>Send the signed-in user's name/email to the agent so it can personalise answers.</summary>
    public bool ForwardUserIdentity { get; set; } = true;
}

/// <summary>
/// Network-level settings for outbound calls (API gateway, proxy, retries). Admin -> Middleware.
/// </summary>
public class MiddlewareOptions
{
    public const string Section = "Middleware";

    /// <summary>Corporate outbound proxy, e.g. http://proxy.moodys.com:8080. Blank = use system default.</summary>
    public string ProxyUrl { get; set; } = "";

    /// <summary>JSON object of extra headers added to every agent call, e.g. an APIM subscription key. Stored encrypted.</summary>
    public string ExtraHeadersJson { get; set; } = "";

    public int HttpTimeoutSeconds { get; set; } = 100;

    public int MaxRetries { get; set; } = 2;

    /// <summary>Trust the X-Forwarded-* headers set by a load balancer or Azure Container Apps ingress.</summary>
    public bool UseForwardedHeaders { get; set; } = true;
}

/// <summary>
/// Sign-in configuration. Admin -> Authentication. Changes here need an app restart.
/// </summary>
public class AuthOptions
{
    public const string Section = "Auth";

    /// <summary>"Okta", "EntraId" (Azure AD), or "DevBypass" (no real sign-in - local testing only).</summary>
    public string Mode { get; set; } = "DevBypass";

    /// <summary>
    /// Okta:    https://moodys.okta.com/oauth2/default  (or your custom authorization server)
    /// EntraId: https://login.microsoftonline.com/{tenant-id}/v2.0
    /// </summary>
    public string Authority { get; set; } = "";

    public string ClientId { get; set; } = "";

    /// <summary>Stored encrypted. Leave blank if your Okta app uses PKCE without a secret.</summary>
    public string ClientSecret { get; set; } = "";

    public string Scopes { get; set; } = "openid profile email";

    /// <summary>Must match the Sign-in redirect URI registered in Okta, path part only.</summary>
    public string CallbackPath { get; set; } = "/authorization-code/callback";

    public string SignedOutCallbackPath { get; set; } = "/signout-callback-oidc";

    /// <summary>Claim that carries group membership. Okta: "groups". Entra: "groups" or "roles".</summary>
    public string GroupsClaimType { get; set; } = "groups";

    /// <summary>Comma-separated group names whose members can open the Admin page.</summary>
    public string AdminGroups { get; set; } = "";

    /// <summary>Comma-separated email addresses that can open the Admin page.</summary>
    public string AdminEmails { get; set; } = "";

    /// <summary>Leave true. Only turn off against a local test IdP over plain http.</summary>
    public bool RequireHttpsMetadata { get; set; } = true;

    public bool UsePkce { get; set; } = true;

    /// <summary>Session lifetime in hours before the user is asked to sign in again.</summary>
    public int SessionHours { get; set; } = 8;
}

/// <summary>Branding shown in the shell. Admin -> Appearance.</summary>
public class BrandOptions
{
    public const string Section = "Brand";

    public string ProductName { get; set; } = "Pathfinder";
    public string ChatTitle { get; set; } = "Pathfinder Chat";
    public string HeroPrompt { get; set; } = "What do you want to do today?";
    public string ComposerPlaceholder { get; set; } = "Describe a project or process...";

    /// <summary>Pipe-separated starter prompts shown on an empty conversation.</summary>
    public string SuggestedPrompts { get; set; } =
        "Please create business requirements for a new project|" +
        "Please use the requirement meeting notes to draft a summary|" +
        "Please create a BRD document from this process";
}
