using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace Pathfinder.Web.Services;

/// <summary>
/// Talks to a Microsoft Copilot Studio agent over the Direct Line channel.
///
/// The exchange is always the same three steps:
///   1. get a Direct Line token - either from the Copilot Studio token endpoint,
///      or by trading an Azure Bot Service Direct Line secret for one
///   2. create a conversation with that token
///   3. post the user message, then poll for the agent's activities
///
/// Polling is used rather than the WebSocket stream because corporate proxies and
/// Azure Container Apps ingress both handle plain HTTPS reliably, and a request here
/// is a single user turn rather than a long-lived connection.
/// </summary>
public sealed class CopilotClient
{
    private readonly AgentHttpClientProvider _clients;
    private readonly SettingsService _settings;
    private readonly ILogger<CopilotClient> _log;

    public CopilotClient(AgentHttpClientProvider clients, SettingsService settings, ILogger<CopilotClient> log)
    {
        _clients = clients;
        _settings = settings;
        _log = log;
    }

    public AgentOptions Options => _settings.Load<AgentOptions>(AgentOptions.Section);
    public MiddlewareOptions Middleware => _settings.Load<MiddlewareOptions>(MiddlewareOptions.Section);

    /// <summary>False until an admin has filled in the token endpoint or Direct Line secret.</summary>
    public bool IsConfigured
    {
        get
        {
            var o = Options;
            return o.Mode.Equals("DirectLineSecret", StringComparison.OrdinalIgnoreCase)
                ? !string.IsNullOrWhiteSpace(o.DirectLineSecret)
                : !string.IsNullOrWhiteSpace(o.TokenEndpoint);
        }
    }

    // ---------------------------------------------------------------- sessions

    /// <summary>Gets a Direct Line token and opens a conversation on it.</summary>
    public async Task<AgentSession> StartSessionAsync(string userId, string userName, CancellationToken ct)
    {
        var o = Options;
        var m = Middleware;

        if (!IsConfigured)
        {
            throw new AgentException(
                "No Copilot agent is connected yet. An administrator needs to fill in the " +
                "token endpoint on the Admin page, under Agent.");
        }

        var (token, expiresIn) = await GetTokenAsync(o, m, userId, userName, ct);

        // Creating the conversation returns the definitive conversation id, and often a
        // longer-lived token than the one used to authenticate this call.
        using var doc = await SendJsonAsync(
            m,
            () => Request(HttpMethod.Post, Base(o) + "/v3/directline/conversations", token, m),
            "start a conversation", ct);

        var root = doc.RootElement;
        var conversationId = Str(root, "conversationId")
            ?? throw new AgentException("Direct Line did not return a conversation id.");
        var sessionToken = Str(root, "token") ?? token;
        var lifetime = Int(root, "expires_in") ?? expiresIn;

        return new AgentSession(conversationId, sessionToken, DateTime.UtcNow.AddSeconds(lifetime));
    }

    /// <summary>
    /// Direct Line tokens last about an hour. A conversation left open in a browser tab
    /// outlives that, so refresh when the token is close to expiring.
    /// </summary>
    public async Task<AgentSession> EnsureFreshAsync(AgentSession session, CancellationToken ct)
    {
        if (session.ExpiresUtc > DateTime.UtcNow.AddMinutes(5)) return session;

        var o = Options;
        var m = Middleware;

        using var doc = await SendJsonAsync(
            m,
            () => Request(HttpMethod.Post, Base(o) + "/v3/directline/tokens/refresh", session.Token, m),
            "refresh the agent token", ct);

        var token = Str(doc.RootElement, "token") ?? session.Token;
        var lifetime = Int(doc.RootElement, "expires_in") ?? 3600;
        return session with { Token = token, ExpiresUtc = DateTime.UtcNow.AddSeconds(lifetime) };
    }

    // ---------------------------------------------------------------- messaging

    /// <summary>
    /// Copilot Studio agents send their opening message in response to this event rather
    /// than on conversation creation, so new threads post it before the first user turn.
    /// </summary>
    public async Task<AgentTurn> SendStartEventAsync(AgentSession session, string userId, string userName, CancellationToken ct)
    {
        var activity = new Dictionary<string, object?>
        {
            ["type"] = "event",
            ["name"] = "startConversation",
            ["from"] = From(userId, userName),
            ["locale"] = "en-US",
        };

        await PostActivityAsync(session, activity, ct);
        return await CollectAsync(session, userId, null, Options, ct);
    }

    /// <summary>Posts one user message and waits for everything the agent says back.</summary>
    public async Task<AgentTurn> SendMessageAsync(
        AgentSession session, string userId, string userName, string? userEmail,
        string text, string? watermark, CancellationToken ct)
    {
        var o = Options;

        var activity = new Dictionary<string, object?>
        {
            ["type"] = "message",
            ["from"] = From(userId, userName),
            ["text"] = text,
            ["locale"] = "en-US",
        };

        if (o.ForwardUserIdentity)
        {
            // Copilot Studio topics can read these off Activity.ChannelData to greet the
            // user by name or scope answers to their team.
            activity["channelData"] = new Dictionary<string, object?>
            {
                ["userName"] = userName,
                ["userEmail"] = userEmail ?? "",
                ["clientApp"] = "Pathfinder UI",
            };
        }

        await PostActivityAsync(session, activity, ct);
        return await CollectAsync(session, userId, watermark, o, ct);
    }

    private async Task PostActivityAsync(AgentSession session, Dictionary<string, object?> activity, CancellationToken ct)
    {
        var o = Options;
        var m = Middleware;
        var json = JsonSerializer.Serialize(activity);
        var url = Base(o) + "/v3/directline/conversations/"
                  + Uri.EscapeDataString(session.ConversationId) + "/activities";

        using var response = await SendJsonAsync(
            m,
            () =>
            {
                var req = Request(HttpMethod.Post, url, session.Token, m);
                req.Content = new StringContent(json, Encoding.UTF8, "application/json");
                return req;
            },
            "send the message", ct);
    }

    /// <summary>
    /// Polls until the agent stops talking. An agent often answers with several activities
    /// in a row - a sentence, then a table, then a file - so once the first reply arrives we
    /// keep waiting for a short quiet period rather than returning immediately.
    /// </summary>
    private async Task<AgentTurn> CollectAsync(
        AgentSession session, string userId, string? watermark, AgentOptions o, CancellationToken ct)
    {
        var turn = new AgentTurn { Watermark = watermark };
        var elapsed = Stopwatch.StartNew();
        var timeout = TimeSpan.FromSeconds(Math.Clamp(o.ReplyTimeoutSeconds, 10, 600));
        var quiet = TimeSpan.FromMilliseconds(Math.Clamp(o.QuietPeriodMs, 200, 15000));
        var poll = Math.Clamp(o.PollIntervalMs, 200, 5000);

        DateTime? lastReplyAt = null;
        var expectingInput = false;

        while (elapsed.Elapsed < timeout)
        {
            var (activities, newWatermark) = await PollAsync(session, turn.Watermark, ct);
            if (newWatermark is not null) turn.Watermark = newWatermark;

            foreach (var activity in activities)
            {
                if (IsFromUser(activity, userId)) continue;
                if (!string.Equals(Str(activity, "type"), "message", StringComparison.OrdinalIgnoreCase)) continue;

                var reply = ToReply(activity);
                if (reply is null) continue;

                turn.Replies.Add(reply);
                lastReplyAt = DateTime.UtcNow;

                if (string.Equals(Str(activity, "inputHint"), "expectingInput", StringComparison.OrdinalIgnoreCase))
                    expectingInput = true;
            }

            // The agent explicitly handed the turn back, so nothing more is coming.
            if (expectingInput && turn.Replies.Count > 0) return turn;

            if (lastReplyAt is { } last && DateTime.UtcNow - last >= quiet) return turn;

            await Task.Delay(poll, ct);
        }

        turn.TimedOut = turn.Replies.Count == 0;
        return turn;
    }

    private async Task<(List<JsonElement> Activities, string? Watermark)> PollAsync(
        AgentSession session, string? watermark, CancellationToken ct)
    {
        var o = Options;
        var m = Middleware;

        var url = Base(o) + "/v3/directline/conversations/"
                  + Uri.EscapeDataString(session.ConversationId) + "/activities";
        if (!string.IsNullOrEmpty(watermark))
            url += "?watermark=" + Uri.EscapeDataString(watermark);

        using var doc = await SendJsonAsync(
            m, () => Request(HttpMethod.Get, url, session.Token, m), "read the agent replies", ct);

        var activities = new List<JsonElement>();
        if (doc.RootElement.TryGetProperty("activities", out var list) && list.ValueKind == JsonValueKind.Array)
        {
            // Clone, because the JsonDocument is disposed when this method returns.
            foreach (var item in list.EnumerateArray()) activities.Add(item.Clone());
        }

        return (activities, Str(doc.RootElement, "watermark"));
    }

    // ---------------------------------------------------------------- diagnostics

    /// <summary>Runs the full handshake and reports what happened, for the Admin page Test button.</summary>
    public async Task<(bool Ok, string Summary, string Detail)> TestConnectionAsync(CancellationToken ct)
    {
        var elapsed = Stopwatch.StartNew();
        try
        {
            var session = await StartSessionAsync("dl_connection_test", "Connection test", ct);
            var lines = new List<string>
            {
                "Token acquired and conversation opened.",
                "Conversation id: " + session.ConversationId,
                "Token valid until: " + session.ExpiresUtc.ToString("u"),
            };

            if (Options.SendStartConversationEvent)
            {
                var greeting = await SendStartEventAsync(session, "dl_connection_test", "Connection test", ct);
                lines.Add(greeting.Replies.Count > 0
                    ? "Agent greeting received (" + greeting.Replies.Count + " message): " + Trim(greeting.Replies[0].Text, 160)
                    : "No greeting received. That is normal if the agent has no opening message.");
            }

            lines.Add("Round trip: " + elapsed.ElapsedMilliseconds + " ms");
            return (true, "Connected to the agent successfully.", string.Join("\n", lines));
        }
        catch (Exception ex)
        {
            return (false, "Could not reach the agent.", ex.Message);
        }
    }

    // ---------------------------------------------------------------- tokens

    private async Task<(string Token, int ExpiresIn)> GetTokenAsync(
        AgentOptions o, MiddlewareOptions m, string userId, string userName, CancellationToken ct)
    {
        if (o.Mode.Equals("DirectLineSecret", StringComparison.OrdinalIgnoreCase))
        {
            var body = JsonSerializer.Serialize(new Dictionary<string, object?>
            {
                ["user"] = From(userId, userName),
            });

            using var secretDoc = await SendJsonAsync(
                m,
                () =>
                {
                    var req = Request(HttpMethod.Post, Base(o) + "/v3/directline/tokens/generate", o.DirectLineSecret, m);
                    req.Content = new StringContent(body, Encoding.UTF8, "application/json");
                    return req;
                },
                "generate a token from the Direct Line secret", ct);

            var secretToken = Str(secretDoc.RootElement, "token")
                ?? throw new AgentException("Direct Line did not return a token.");
            return (secretToken, Int(secretDoc.RootElement, "expires_in") ?? 3600);
        }

        // Copilot Studio token endpoint: a plain GET that mints a Direct Line token.
        if (!Uri.TryCreate(o.TokenEndpoint, UriKind.Absolute, out _))
            throw new AgentException("The token endpoint is not a valid URL: " + o.TokenEndpoint);

        using var doc = await SendJsonAsync(
            m, () => Request(HttpMethod.Get, o.TokenEndpoint, null, m), "fetch a token from Copilot Studio", ct);

        var token = Str(doc.RootElement, "token")
            ?? throw new AgentException(
                "The token endpoint responded, but the reply contained no token. Check that the URL was " +
                "copied from Copilot Studio, under Channels then Mobile app.");

        return (token, Int(doc.RootElement, "expires_in") ?? 3600);
    }

    // ---------------------------------------------------------------- http plumbing

    private static string Base(AgentOptions o)
        => (string.IsNullOrWhiteSpace(o.DirectLineBaseUrl)
                ? "https://directline.botframework.com"
                : o.DirectLineBaseUrl).TrimEnd('/');

    private HttpRequestMessage Request(HttpMethod method, string url, string? bearer, MiddlewareOptions m)
    {
        var req = new HttpRequestMessage(method, url);
        if (!string.IsNullOrEmpty(bearer))
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        foreach (var header in ExtraHeaders(m))
        {
            req.Headers.Remove(header.Key);
            req.Headers.TryAddWithoutValidation(header.Key, header.Value);
        }
        return req;
    }

    private IEnumerable<KeyValuePair<string, string>> ExtraHeaders(MiddlewareOptions m)
    {
        if (string.IsNullOrWhiteSpace(m.ExtraHeadersJson)) return Array.Empty<KeyValuePair<string, string>>();

        try
        {
            var parsed = JsonSerializer.Deserialize<Dictionary<string, string>>(m.ExtraHeadersJson);
            return parsed is null
                ? Array.Empty<KeyValuePair<string, string>>()
                : parsed.ToArray();
        }
        catch (JsonException ex)
        {
            _log.LogWarning(ex, "Middleware extra headers are not valid JSON and were ignored.");
            return Array.Empty<KeyValuePair<string, string>>();
        }
    }

    /// <summary>
    /// Sends a request, retrying throttling and transient server errors, and turns any
    /// failure into an AgentException whose message is safe to show an administrator.
    /// </summary>
    private async Task<JsonDocument> SendJsonAsync(
        MiddlewareOptions m, Func<HttpRequestMessage> factory, string what, CancellationToken ct)
    {
        var client = _clients.Get(m);
        var attempts = Math.Clamp(m.MaxRetries, 0, 5) + 1;

        for (var attempt = 1; ; attempt++)
        {
            try
            {
                using var request = factory();
                using var response = await client.SendAsync(request, HttpCompletionOption.ResponseContentRead, ct);

                if (response.IsSuccessStatusCode)
                {
                    var body = await response.Content.ReadAsStringAsync(ct);
                    if (string.IsNullOrWhiteSpace(body)) return JsonDocument.Parse("{}");

                    try
                    {
                        return JsonDocument.Parse(body);
                    }
                    catch (JsonException)
                    {
                        throw new AgentException(
                            "Could not " + what + ": the service replied with something that is not JSON. " +
                            "First part of the reply: " + Trim(body, 300));
                    }
                }

                var status = (int)response.StatusCode;
                if ((status == 429 || status >= 500) && attempt < attempts)
                {
                    await Task.Delay(BackoffFor(response, attempt), ct);
                    continue;
                }

                throw new AgentException(await DescribeAsync(response, what, ct), null, status);
            }
            catch (AgentException)
            {
                throw;
            }
            catch (TaskCanceledException) when (!ct.IsCancellationRequested)
            {
                if (attempt < attempts)
                {
                    await Task.Delay(BackoffFor(null, attempt), ct);
                    continue;
                }
                throw new AgentException(
                    "Could not " + what + ": the request timed out after " +
                    client.Timeout.TotalSeconds.ToString("0") + " seconds. If this app sits behind a " +
                    "corporate proxy, set the proxy URL on the Admin page under Middleware.");
            }
            catch (HttpRequestException ex)
            {
                if (attempt < attempts)
                {
                    await Task.Delay(BackoffFor(null, attempt), ct);
                    continue;
                }
                throw new AgentException(
                    "Could not " + what + ": the network call failed (" + ex.Message + "). Check that " +
                    "outbound HTTPS to directline.botframework.com is allowed from this server.", ex);
            }
        }
    }

    private static TimeSpan BackoffFor(HttpResponseMessage? response, int attempt)
    {
        if (response?.Headers.RetryAfter?.Delta is { } delta) return delta;
        if (response?.Headers.RetryAfter?.Date is { } date)
        {
            var wait = date - DateTimeOffset.UtcNow;
            if (wait > TimeSpan.Zero) return wait;
        }
        return TimeSpan.FromMilliseconds(400 * Math.Pow(2, attempt - 1));
    }

    private static async Task<string> DescribeAsync(HttpResponseMessage response, string what, CancellationToken ct)
    {
        var body = Trim(await response.Content.ReadAsStringAsync(ct), 400);
        var code = (int)response.StatusCode;

        var hint = code switch
        {
            401 => " The credentials were rejected. Re-copy the token endpoint or Direct Line secret on the Admin page.",
            403 => " Access was refused. The agent may not be published, or its Direct Line channel may be turned off.",
            404 => " The URL was not found. Check the token endpoint for a typo or a missing api-version.",
            429 => " The agent is being throttled. Wait a moment and try again.",
            >= 500 => " The Copilot service is having trouble. This is usually temporary.",
            _ => "",
        };

        var message = "Could not " + what + ": " + code + " " + response.ReasonPhrase + "." + hint;
        return body.Length > 0 ? message + "\n\nService reply: " + body : message;
    }

    // ---------------------------------------------------------------- activity parsing

    private static Dictionary<string, object?> From(string userId, string userName) => new()
    {
        ["id"] = userId,
        ["name"] = userName,
        ["role"] = "user",
    };

    private static bool IsFromUser(JsonElement activity, string userId)
        => activity.TryGetProperty("from", out var from)
           && string.Equals(Str(from, "id"), userId, StringComparison.OrdinalIgnoreCase);

    /// <summary>Turns a Direct Line message activity into something the UI can render, or null if it is empty.</summary>
    private static AgentReply? ToReply(JsonElement activity)
    {
        var reply = new AgentReply { Text = Str(activity, "text") ?? "" };

        if (activity.TryGetProperty("attachments", out var attachments) && attachments.ValueKind == JsonValueKind.Array)
        {
            foreach (var attachment in attachments.EnumerateArray())
            {
                var contentType = Str(attachment, "contentType") ?? "";
                var contentUrl = Str(attachment, "contentUrl");

                // A real file the user can download. This is what produces the chips under a
                // reply when the agent generates a Word or Excel document.
                if (!string.IsNullOrWhiteSpace(contentUrl))
                {
                    reply.Attachments.Add(new AgentAttachment(
                        Str(attachment, "name") ?? FileNameFrom(contentUrl),
                        contentUrl,
                        contentType));
                    continue;
                }

                // A card. Pull its text out so the reply is not silently blank.
                if (attachment.TryGetProperty("content", out var content))
                {
                    var cardText = CardText(content);
                    if (cardText.Length > 0)
                        reply.Text = reply.Text.Length > 0 ? reply.Text + "\n\n" + cardText : cardText;
                }
            }
        }

        if (activity.TryGetProperty("suggestedActions", out var suggested)
            && suggested.ValueKind == JsonValueKind.Object
            && suggested.TryGetProperty("actions", out var actions)
            && actions.ValueKind == JsonValueKind.Array)
        {
            foreach (var action in actions.EnumerateArray())
            {
                var title = Str(action, "title");
                if (string.IsNullOrWhiteSpace(title)) continue;
                reply.Suggestions.Add(new AgentSuggestion(title, Str(action, "value") ?? title));
            }
        }

        var isEmpty = reply.Text.Length == 0 && reply.Attachments.Count == 0 && reply.Suggestions.Count == 0;
        return isEmpty ? null : reply;
    }

    /// <summary>Flattens an adaptive card or hero card into plain text.</summary>
    private static string CardText(JsonElement content)
    {
        var parts = new List<string>();
        if (content.ValueKind != JsonValueKind.Object) return "";

        if (Str(content, "title") is { Length: > 0 } title) parts.Add(title);
        if (Str(content, "subtitle") is { Length: > 0 } subtitle) parts.Add(subtitle);
        if (Str(content, "text") is { Length: > 0 } text) parts.Add(text);

        if (content.TryGetProperty("body", out var body) && body.ValueKind == JsonValueKind.Array)
            CollectTextBlocks(body, parts);

        return string.Join("\n\n", parts);
    }

    private static void CollectTextBlocks(JsonElement array, List<string> into)
    {
        foreach (var node in array.EnumerateArray())
        {
            if (node.ValueKind != JsonValueKind.Object) continue;

            if (string.Equals(Str(node, "type"), "TextBlock", StringComparison.OrdinalIgnoreCase)
                && Str(node, "text") is { Length: > 0 } text)
            {
                into.Add(text);
            }

            // Containers and column sets nest their own items.
            foreach (var childName in new[] { "items", "columns", "body" })
            {
                if (node.TryGetProperty(childName, out var child) && child.ValueKind == JsonValueKind.Array)
                    CollectTextBlocks(child, into);
            }
        }
    }

    private static string FileNameFrom(string url)
    {
        try
        {
            var name = Path.GetFileName(new Uri(url).AbsolutePath);
            return string.IsNullOrWhiteSpace(name) ? "attachment" : Uri.UnescapeDataString(name);
        }
        catch
        {
            return "attachment";
        }
    }

    private static string? Str(JsonElement element, string name)
        => element.ValueKind == JsonValueKind.Object
           && element.TryGetProperty(name, out var value)
           && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    private static int? Int(JsonElement element, string name)
        => element.ValueKind == JsonValueKind.Object
           && element.TryGetProperty(name, out var value)
           && value.ValueKind == JsonValueKind.Number
           && value.TryGetInt32(out var number)
            ? number
            : null;

    private static string Trim(string? text, int max)
    {
        if (string.IsNullOrEmpty(text)) return "";
        text = text.Replace("\r", " ").Replace("\n", " ").Trim();
        return text.Length <= max ? text : text[..max] + "...";
    }
}
