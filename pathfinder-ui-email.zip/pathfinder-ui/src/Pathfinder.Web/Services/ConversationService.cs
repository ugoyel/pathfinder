using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Pathfinder.Web.Data;

namespace Pathfinder.Web.Services;

/// <summary>The signed-in person, flattened out of the claims principal.</summary>
public sealed record CurrentUser(string Id, string Name, string Email, bool IsAdmin)
{
    /// <summary>
    /// The id given to Direct Line. It is a hash rather than the email so the agent
    /// transcript never carries personal data in its user id, and Direct Line requires
    /// the "dl_" prefix for ids minted by a token rather than a secret.
    /// </summary>
    public string DirectLineUserId
    {
        get
        {
            var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(Id));
            return "dl_" + Convert.ToHexString(bytes)[..24].ToLowerInvariant();
        }
    }
}

/// <summary>
/// Owns the chat history: which threads a user has, what was said in each, and the
/// Direct Line session each thread is bound to.
/// </summary>
public sealed class ConversationService
{
    private readonly AppDbContext _db;
    private readonly CopilotClient _agent;
    private readonly ISecretProtector _protector;
    private readonly ILogger<ConversationService> _log;

    public ConversationService(
        AppDbContext db, CopilotClient agent, ISecretProtector protector, ILogger<ConversationService> log)
    {
        _db = db;
        _agent = agent;
        _protector = protector;
        _log = log;
    }

    // ---------------------------------------------------------------- reading

    /// <summary>The left-hand list: most recently used thread first.</summary>
    public async Task<List<Conversation>> ListAsync(CurrentUser user, int take = 200)
        => await _db.Conversations
            .AsNoTracking()
            .Where(c => c.UserId == user.Id && !c.IsArchived)
            .OrderByDescending(c => c.UpdatedUtc)
            .Take(take)
            .ToListAsync();

    /// <summary>Loads one thread with its messages, or null when it is missing or owned by someone else.</summary>
    public async Task<Conversation?> GetAsync(CurrentUser user, Guid id)
        => await _db.Conversations
            .Include(c => c.Messages.OrderBy(m => m.CreatedUtc))
            .FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);

    // ---------------------------------------------------------------- writing

    public async Task<Conversation> CreateAsync(CurrentUser user)
    {
        var conversation = new Conversation { UserId = user.Id, Title = "New conversation" };
        _db.Conversations.Add(conversation);
        await _db.SaveChangesAsync();
        return conversation;
    }

    public async Task<bool> RenameAsync(CurrentUser user, Guid id, string title)
    {
        var conversation = await _db.Conversations.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
        if (conversation is null) return false;

        conversation.Title = Shorten(title, 120);
        conversation.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteAsync(CurrentUser user, Guid id)
    {
        var conversation = await _db.Conversations.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
        if (conversation is null) return false;

        _db.Conversations.Remove(conversation);
        await _db.SaveChangesAsync();
        return true;
    }

    // ---------------------------------------------------------------- the chat turn

    /// <summary>
    /// Records the user message, asks the agent, records the reply, and returns the
    /// thread. Creates the thread when conversationId is null.
    /// </summary>
    public async Task<(Conversation Conversation, List<Message> New)> SendAsync(
        CurrentUser user, Guid? conversationId, string text, CancellationToken ct)
    {
        var conversation = conversationId is { } id
            ? await _db.Conversations.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id)
              ?? throw new InvalidOperationException("Conversation not found.")
            : new Conversation { UserId = user.Id };

        if (conversationId is null) _db.Conversations.Add(conversation);

        var userMessage = new Message
        {
            ConversationId = conversation.Id,
            Role = "user",
            Text = text,
        };
        _db.Messages.Add(userMessage);

        // The first thing a person types becomes the thread name in the sidebar, which is
        // what makes the list scannable later. Only the untouched default is replaced, so a
        // thread the user renamed keeps its name.
        if (conversation.Title is "New conversation" or "")
            conversation.Title = Shorten(text, 60);

        var created = new List<Message> { userMessage };

        try
        {
            var turn = await AskAgentAsync(user, conversation, text, ct);

            if (turn.Replies.Count == 0)
            {
                created.Add(Record(conversation, turn.TimedOut
                    ? "The agent did not reply in time. It may still be working on a long task - " +
                      "try asking again, or ask an administrator to raise the reply timeout."
                    : "The agent finished without saying anything.", isError: turn.TimedOut));
            }
            else
            {
                foreach (var reply in turn.Replies)
                {
                    var message = Record(conversation, reply.Text);
                    if (reply.Attachments.Count > 0)
                        message.AttachmentsJson = JsonSerializer.Serialize(reply.Attachments);
                    if (reply.Suggestions.Count > 0)
                        message.SuggestedActionsJson = JsonSerializer.Serialize(reply.Suggestions);
                    created.Add(message);
                }
            }
        }
        catch (AgentException ex)
        {
            _log.LogWarning(ex, "Agent call failed for conversation {ConversationId}", conversation.Id);
            created.Add(Record(conversation, ex.Message, isError: true));
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Unexpected failure talking to the agent for conversation {ConversationId}", conversation.Id);
            created.Add(Record(conversation, "Something went wrong talking to the agent. Please try again.", isError: true));
        }

        conversation.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return (conversation, created);
    }

    /// <summary>
    /// Sends one turn, reconnecting if the stored Direct Line session has aged out.
    /// A conversation left open overnight is the normal way this happens.
    /// </summary>
    private async Task<AgentTurn> AskAgentAsync(CurrentUser user, Conversation conversation, string text, CancellationToken ct)
    {
        var session = await ResumeOrStartAsync(user, conversation, ct);

        try
        {
            var turn = await _agent.SendMessageAsync(
                session, user.DirectLineUserId, user.Name, user.Email, text, conversation.Watermark, ct);
            Persist(conversation, session, turn.Watermark);
            return turn;
        }
        catch (AgentException ex) when (conversation.DirectLineConversationId is not null && ex.IsStaleSession)
        {
            // Direct Line rejected the conversation, which is what an expired session looks
            // like. Start a clean one and try once more: the agent loses its own memory of
            // the thread, but the user keeps their transcript.
            //
            // Only a rejection is retried. Reconnecting after a network outage would just
            // make the user wait through a second round of timeouts for the same error.
            _log.LogInformation("Direct Line session expired for {ConversationId}; reconnecting.", conversation.Id);

            var fresh = await StartFreshAsync(user, conversation, ct);
            var turn = await _agent.SendMessageAsync(
                fresh, user.DirectLineUserId, user.Name, user.Email, text, null, ct);
            Persist(conversation, fresh, turn.Watermark);
            return turn;
        }
    }

    private async Task<AgentSession> ResumeOrStartAsync(CurrentUser user, Conversation conversation, CancellationToken ct)
    {
        if (conversation.DirectLineConversationId is { Length: > 0 } existingId
            && conversation.DirectLineTokenProtected is { Length: > 0 } protectedToken)
        {
            var token = _protector.Unprotect(protectedToken);
            if (token.Length > 0)
            {
                var session = new AgentSession(
                    existingId, token, conversation.DirectLineTokenExpiresUtc ?? DateTime.UtcNow);
                try
                {
                    return await _agent.EnsureFreshAsync(session, ct);
                }
                catch (AgentException ex)
                {
                    _log.LogInformation(ex, "Token refresh failed for {ConversationId}; starting a new session.", conversation.Id);
                }
            }
        }

        return await StartFreshAsync(user, conversation, ct);
    }

    private async Task<AgentSession> StartFreshAsync(CurrentUser user, Conversation conversation, CancellationToken ct)
    {
        var session = await _agent.StartSessionAsync(user.DirectLineUserId, user.Name, ct);
        conversation.Watermark = null;

        if (_agent.Options.SendStartConversationEvent)
        {
            // Copilot Studio needs this before it will run the agent's opening topic.
            // The greeting itself is normally dropped: the hero prompt already covers it.
            var greeting = await _agent.SendStartEventAsync(session, user.DirectLineUserId, user.Name, ct);
            conversation.Watermark = greeting.Watermark;

            if (_agent.Options.ShowGreeting)
            {
                foreach (var reply in greeting.Replies.Where(r => r.Text.Length > 0))
                    Record(conversation, reply.Text);
            }
        }

        Persist(conversation, session, conversation.Watermark);
        return session;
    }

    private void Persist(Conversation conversation, AgentSession session, string? watermark)
    {
        conversation.DirectLineConversationId = session.ConversationId;
        conversation.DirectLineTokenProtected = _protector.Protect(session.Token);
        conversation.DirectLineTokenExpiresUtc = session.ExpiresUtc;
        if (watermark is not null) conversation.Watermark = watermark;
    }

    private Message Record(Conversation conversation, string text, bool isError = false)
    {
        var message = new Message
        {
            ConversationId = conversation.Id,
            Role = "assistant",
            Text = text,
            IsError = isError,
        };
        _db.Messages.Add(message);
        return message;
    }

    private static string Shorten(string text, int max)
    {
        var clean = text.Replace("\r", " ").Replace("\n", " ").Trim();
        while (clean.Contains("  ")) clean = clean.Replace("  ", " ");
        if (clean.Length == 0) return "New conversation";
        return clean.Length <= max ? clean : clean[..max].TrimEnd() + "...";
    }
}
