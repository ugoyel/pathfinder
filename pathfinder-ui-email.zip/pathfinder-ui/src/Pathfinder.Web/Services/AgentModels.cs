namespace Pathfinder.Web.Services;

/// <summary>A Direct Line conversation handle plus the token that authorises calls on it.</summary>
public sealed record AgentSession(string ConversationId, string Token, DateTime ExpiresUtc);

/// <summary>A file the agent returned, rendered as a download chip under the reply.</summary>
public sealed record AgentAttachment(string Name, string Url, string ContentType);

/// <summary>A quick-reply chip the agent offered.</summary>
public sealed record AgentSuggestion(string Title, string Value);

/// <summary>One reply activity from the agent.</summary>
public sealed class AgentReply
{
    public string Text { get; set; } = "";
    public List<AgentAttachment> Attachments { get; set; } = new();
    public List<AgentSuggestion> Suggestions { get; set; } = new();
}

/// <summary>Everything the agent said in response to one user turn.</summary>
public sealed class AgentTurn
{
    public List<AgentReply> Replies { get; set; } = new();
    public string? Watermark { get; set; }
    public bool TimedOut { get; set; }
}

/// <summary>Raised when the agent cannot be reached or rejects the call.</summary>
public sealed class AgentException : Exception
{
    /// <summary>
    /// The HTTP status Direct Line returned, when there was one. Null means the call never
    /// got an answer at all - a timeout, a DNS failure or a refused connection.
    /// </summary>
    public int? StatusCode { get; }

    public AgentException(string message, Exception? inner = null, int? statusCode = null)
        : base(message, inner)
        => StatusCode = statusCode;

    /// <summary>
    /// True when Direct Line rejected the conversation itself, which is what an expired
    /// session looks like. Worth reconnecting for. A transport failure is not: retrying it
    /// only makes the user wait twice as long for the same error.
    /// </summary>
    public bool IsStaleSession => StatusCode is 401 or 403 or 404;
}
