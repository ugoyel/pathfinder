using System.Net;

namespace Pathfinder.Web.Services;

/// <summary>
/// Hands out the HttpClient used for agent calls, rebuilding it only when the proxy or
/// timeout changes on the Admin page. HttpClient is designed to be long-lived and shared;
/// creating one per request would exhaust sockets under load.
/// </summary>
public sealed class AgentHttpClientProvider
{
    private readonly object _gate = new();
    private string _signature = "";
    private HttpClient? _client;

    public HttpClient Get(MiddlewareOptions m)
    {
        var signature = $"{m.ProxyUrl}|{m.HttpTimeoutSeconds}";

        lock (_gate)
        {
            if (_client is not null && signature == _signature) return _client;

            var handler = new SocketsHttpHandler
            {
                AllowAutoRedirect = true,
                AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate,

                // A firewall that drops packets rather than refusing them would otherwise
                // hold the request open for the full timeout on every retry, leaving the
                // user watching a spinner. Fail the connection attempt quickly instead.
                ConnectTimeout = TimeSpan.FromSeconds(15),

                // Recycle connections so a DNS change on the Copilot side is picked up
                // without restarting the app.
                PooledConnectionLifetime = TimeSpan.FromMinutes(5),
            };

            if (!string.IsNullOrWhiteSpace(m.ProxyUrl))
            {
                handler.Proxy = new WebProxy(m.ProxyUrl);
                handler.UseProxy = true;
                // Corporate proxies on a domain-joined host usually want the process identity.
                handler.DefaultProxyCredentials = CredentialCache.DefaultCredentials;
            }

            // The previous client is intentionally not disposed: requests may still be in
            // flight on it. Config changes are rare and admin-initiated, so letting the GC
            // collect it once those finish is cheaper than cancelling live calls.
            _client = new HttpClient(handler)
            {
                Timeout = TimeSpan.FromSeconds(Math.Clamp(m.HttpTimeoutSeconds, 5, 600)),
            };
            _client.DefaultRequestHeaders.UserAgent.ParseAdd("Pathfinder-UI/1.0");
            _signature = signature;
            return _client;
        }
    }
}
