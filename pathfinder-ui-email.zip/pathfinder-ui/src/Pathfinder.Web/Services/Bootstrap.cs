using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;
using Pathfinder.Web.Data;

namespace Pathfinder.Web.Services;

/// <summary>
/// Startup wiring that is needed twice: once by the app itself, and once before the app
/// exists, to read the sign-in settings out of the database so the OpenID Connect
/// handler can be configured with them.
/// </summary>
public static class Bootstrap
{
    /// <summary>
    /// Where the database and the encryption key ring live. Defaults to App_Data beside
    /// the app. In a container, point Storage:DataPath at a mounted volume - otherwise a
    /// redeploy loses the chat history and the keys that decrypt the stored secrets.
    /// </summary>
    public static string DataDirectory(IConfiguration config, string contentRoot)
    {
        var configured = config["Storage:DataPath"];
        var dir = string.IsNullOrWhiteSpace(configured)
            ? Path.Combine(contentRoot, "App_Data")
            : Path.IsPathRooted(configured) ? configured : Path.Combine(contentRoot, configured);

        Directory.CreateDirectory(dir);
        return dir;
    }

    /// <summary>SQLite by default so the app runs with no infrastructure; SQL Server when configured.</summary>
    public static void AddDatabase(IServiceCollection services, IConfiguration config, string dataDir)
    {
        var provider = config["Database:Provider"] ?? "Sqlite";
        var connection = config.GetConnectionString("Default");

        services.AddDbContext<AppDbContext>(options =>
        {
            if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrWhiteSpace(connection))
                    throw new InvalidOperationException(
                        "Database:Provider is SqlServer but ConnectionStrings:Default is empty.");
                options.UseSqlServer(connection);
            }
            else
            {
                options.UseSqlite(string.IsNullOrWhiteSpace(connection)
                    ? "Data Source=" + Path.Combine(dataDir, "pathfinder.db")
                    : connection);
            }
        });
    }

    /// <summary>
    /// The key ring that encrypts stored secrets. Both this and the startup-time copy must
    /// use the same folder and application name, or a secret saved by the running app
    /// cannot be read back the next time it starts.
    /// </summary>
    public static void AddKeyRing(IServiceCollection services, string dataDir)
    {
        services.AddDataProtection()
            .PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(dataDir, "keys")))
            .SetApplicationName("Pathfinder");
    }

    /// <summary>
    /// Reads sign-in settings before the web host is built. OpenID Connect options are
    /// fixed when the handler is registered, which is why changing them on the Admin page
    /// asks for a restart.
    /// </summary>
    public static AuthOptions LoadStartupAuth(IConfiguration config, string dataDir, ILoggerFactory loggers)
    {
        var fallback = new AuthOptions();
        config.GetSection(AuthOptions.Section).Bind(fallback);

        try
        {
            var services = new ServiceCollection();
            services.AddSingleton(config);
            services.AddSingleton(loggers);
            services.AddLogging();
            services.AddSingleton<SettingsCache>();
            services.AddSingleton<ISecretProtector, SecretProtector>();
            services.AddScoped<SettingsService>();
            AddDatabase(services, config, dataDir);
            AddKeyRing(services, dataDir);

            using var provider = services.BuildServiceProvider();
            using var scope = provider.CreateScope();

            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            db.Database.EnsureCreated();

            return scope.ServiceProvider.GetRequiredService<SettingsService>().Load<AuthOptions>(AuthOptions.Section);
        }
        catch (Exception ex)
        {
            // A database that is not reachable yet must not stop the app from starting,
            // or an admin has no way in to fix the connection string.
            loggers.CreateLogger("Pathfinder.Bootstrap").LogWarning(
                ex, "Could not read sign-in settings from the database. Falling back to appsettings.json.");
            return fallback;
        }
    }
}
