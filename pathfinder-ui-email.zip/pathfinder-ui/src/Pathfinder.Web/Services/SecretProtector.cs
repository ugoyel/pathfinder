using Microsoft.AspNetCore.DataProtection;

namespace Pathfinder.Web.Services;

/// <summary>
/// Encrypts admin-entered secrets (Direct Line secret, Okta client secret, gateway keys)
/// before they are written to the database, so the .db file alone never reveals them.
/// </summary>
public interface ISecretProtector
{
    string Protect(string plaintext);
    string Unprotect(string ciphertext);
}

public sealed class SecretProtector : ISecretProtector
{
    private readonly IDataProtector _protector;
    private readonly ILogger<SecretProtector> _log;

    public SecretProtector(IDataProtectionProvider provider, ILogger<SecretProtector> log)
    {
        _protector = provider.CreateProtector("Pathfinder.Settings.v1");
        _log = log;
    }

    public string Protect(string plaintext)
        => string.IsNullOrEmpty(plaintext) ? "" : _protector.Protect(plaintext);

    public string Unprotect(string ciphertext)
    {
        if (string.IsNullOrEmpty(ciphertext)) return "";
        try
        {
            return _protector.Unprotect(ciphertext);
        }
        catch (Exception ex)
        {
            // Happens when the Data Protection key ring is lost (e.g. the container was
            // rebuilt without a persistent key folder). The admin must re-enter the secret.
            _log.LogWarning(ex, "Could not decrypt a stored secret. It needs to be re-entered on the Admin page.");
            return "";
        }
    }
}
