using Pathfinder.Web.Auth;
using Pathfinder.Web.Models;

namespace Pathfinder.Web.Services;

/// <summary>Builds the view model for the shared shell so every page renders the same rail and header.</summary>
public sealed class ShellFactory
{
    private readonly UserContext _users;
    private readonly SettingsService _settings;
    private readonly CopilotClient _agent;
    private readonly AuthOptions _activeAuth;

    public ShellFactory(UserContext users, SettingsService settings, CopilotClient agent, AuthOptions activeAuth)
    {
        _users = users;
        _settings = settings;
        _agent = agent;
        _activeAuth = activeAuth;
    }

    public ShellViewModel Build(string activeNav)
    {
        var user = _users.Current;

        return new ShellViewModel
        {
            Brand = _settings.Load<BrandOptions>(BrandOptions.Section),
            UserName = user?.Name ?? "",
            UserEmail = user?.Email ?? "",
            IsAdmin = user?.IsAdmin ?? false,
            AgentName = _agent.Options.AgentDisplayName,
            ActiveNav = activeNav,
            AgentConfigured = _agent.IsConfigured,
            UsingLocalSignIn = _activeAuth.Mode.Equals("DevBypass", StringComparison.OrdinalIgnoreCase),
        };
    }
}
