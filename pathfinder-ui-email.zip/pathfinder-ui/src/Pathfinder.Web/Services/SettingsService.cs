using System.Collections.Concurrent;
using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Pathfinder.Web.Data;

namespace Pathfinder.Web.Services;

/// <summary>
/// Process-wide cache of the settings table, so a chat request does not hit the
/// database for configuration on every keystroke. Cleared whenever an admin saves.
/// </summary>
public sealed class SettingsCache
{
    private ConcurrentDictionary<string, AppSetting>? _rows;

    public ConcurrentDictionary<string, AppSetting>? Rows => _rows;
    public void Set(IEnumerable<AppSetting> rows)
        => _rows = new ConcurrentDictionary<string, AppSetting>(
            rows.ToDictionary(r => r.Key, r => r), StringComparer.OrdinalIgnoreCase);
    public void Invalidate() => _rows = null;
}

/// <summary>
/// Reads and writes admin-editable configuration.
///
/// Precedence, lowest to highest:
///   1. the defaults written in the AppOptions classes
///   2. appsettings.json / environment variables
///   3. the Settings table, which is what the Admin page writes
///
/// So appsettings.json seeds a fresh deployment, and after that the Admin page wins.
/// "Reload from appsettings" on the Admin page deletes the database rows for a section
/// and hands control back to the file.
/// </summary>
public sealed class SettingsService
{
    /// <summary>Values encrypted at rest and masked in the Admin UI.</summary>
    public static readonly HashSet<string> SecretKeys = new(StringComparer.OrdinalIgnoreCase)
    {
        "Agent:DirectLineSecret",
        "Auth:ClientSecret",
        "Middleware:ExtraHeadersJson",
    };

    /// <summary>What the Admin page shows instead of a stored secret. Saving it back means "leave unchanged".</summary>
    public const string SecretPlaceholder = "********";

    private readonly AppDbContext _db;
    private readonly IConfiguration _config;
    private readonly ISecretProtector _protector;
    private readonly SettingsCache _cache;

    public SettingsService(AppDbContext db, IConfiguration config, ISecretProtector protector, SettingsCache cache)
    {
        _db = db;
        _config = config;
        _protector = protector;
        _cache = cache;
    }

    private IDictionary<string, AppSetting> Rows()
    {
        if (_cache.Rows is { } cached) return cached;
        var rows = _db.Settings.AsNoTracking().ToList();
        _cache.Set(rows);
        return _cache.Rows!;
    }

    public static bool IsSecret(string key) => SecretKeys.Contains(key);

    /// <summary>Loads a section, applying defaults, then appsettings.json, then the database.</summary>
    public T Load<T>(string section) where T : new()
    {
        var target = new T();
        _config.GetSection(section).Bind(target);

        var rows = Rows();
        foreach (var prop in Writable<T>())
        {
            var key = $"{section}:{prop.Name}";
            if (!rows.TryGetValue(key, out var row) || row.Value is null) continue;

            var raw = row.IsSecret ? _protector.Unprotect(row.Value) : row.Value;
            if (TryConvert(raw, prop.PropertyType, out var value))
                prop.SetValue(target, value);
        }
        return target;
    }

    /// <summary>Writes a section to the database. Secrets left at the mask keep their current value.</summary>
    public async Task SaveAsync<T>(string section, T values, string? updatedBy)
    {
        var existing = await _db.Settings.ToDictionaryAsync(s => s.Key, StringComparer.OrdinalIgnoreCase);

        foreach (var prop in Writable<T>())
        {
            var key = $"{section}:{prop.Name}";
            var secret = IsSecret(key);
            var text = prop.GetValue(values)?.ToString() ?? "";

            // The Admin page never receives real secrets, so the mask coming back means "no change".
            if (secret && text == SecretPlaceholder) continue;

            var stored = secret && text.Length > 0 ? _protector.Protect(text) : text;

            if (existing.TryGetValue(key, out var row))
            {
                row.Value = stored;
                row.IsSecret = secret;
                row.UpdatedUtc = DateTime.UtcNow;
                row.UpdatedBy = updatedBy;
                _db.Settings.Update(row);
            }
            else
            {
                _db.Settings.Add(new AppSetting
                {
                    Key = key,
                    Value = stored,
                    IsSecret = secret,
                    UpdatedUtc = DateTime.UtcNow,
                    UpdatedBy = updatedBy,
                });
            }
        }

        await _db.SaveChangesAsync();
        _cache.Invalidate();
    }

    /// <summary>Drops the database rows for a section so appsettings.json takes over again.</summary>
    public async Task ResetSectionAsync(string section)
    {
        var prefix = section + ":";
        var rows = await _db.Settings.Where(s => s.Key.StartsWith(prefix)).ToListAsync();
        _db.Settings.RemoveRange(rows);
        await _db.SaveChangesAsync();
        _cache.Invalidate();
    }

    /// <summary>Returns the section with every secret replaced by the mask, safe to send to the browser.</summary>
    public T LoadMasked<T>(string section) where T : new()
    {
        var value = Load<T>(section);
        foreach (var prop in Writable<T>())
        {
            if (!IsSecret($"{section}:{prop.Name}")) continue;
            var current = prop.GetValue(value)?.ToString() ?? "";
            prop.SetValue(value, current.Length > 0 ? SecretPlaceholder : "");
        }
        return value;
    }

    /// <summary>True when the section has a non-empty stored secret, so the UI can say "configured".</summary>
    public bool HasSecret(string key)
    {
        if (!Rows().TryGetValue(key, out var row) || string.IsNullOrEmpty(row.Value)) return false;
        return _protector.Unprotect(row.Value).Length > 0;
    }

    private static IEnumerable<PropertyInfo> Writable<T>()
        => typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                    .Where(p => p.CanRead && p.CanWrite);

    private static bool TryConvert(string raw, Type type, out object? value)
    {
        value = null;
        try
        {
            if (type == typeof(string)) { value = raw; return true; }
            if (type == typeof(int)) { value = int.Parse(raw); return true; }
            if (type == typeof(bool)) { value = bool.Parse(raw); return true; }
            value = Convert.ChangeType(raw, type);
            return true;
        }
        catch
        {
            return false;
        }
    }
}
