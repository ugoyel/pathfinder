using System.ComponentModel.DataAnnotations;

namespace Pathfinder.Web.Data;

/// <summary>One chat thread. Shown as a row in the left "past searches" list.</summary>
public class Conversation
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>Stable id of the signed-in user (Okta "sub", or the email when sub is absent).</summary>
    [MaxLength(200)]
    public string UserId { get; set; } = "";

    [MaxLength(300)]
    public string Title { get; set; } = "New conversation";

    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    public bool IsArchived { get; set; }

    /// <summary>Direct Line conversation this thread is bound to. Null until the first message.</summary>
    [MaxLength(200)]
    public string? DirectLineConversationId { get; set; }

    /// <summary>Direct Line token, encrypted at rest with ASP.NET Data Protection.</summary>
    public string? DirectLineTokenProtected { get; set; }

    public DateTime? DirectLineTokenExpiresUtc { get; set; }

    /// <summary>Direct Line watermark so we only fetch activities we have not seen.</summary>
    [MaxLength(100)]
    public string? Watermark { get; set; }

    public List<Message> Messages { get; set; } = new();
}

/// <summary>A single turn in a conversation.</summary>
public class Message
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();

    public Guid ConversationId { get; set; }
    public Conversation? Conversation { get; set; }

    /// <summary>"user" or "assistant".</summary>
    [MaxLength(20)]
    public string Role { get; set; } = "user";

    public string Text { get; set; } = "";

    /// <summary>JSON array of { name, url, contentType } for files the agent returned.</summary>
    public string? AttachmentsJson { get; set; }

    /// <summary>JSON array of { title, value } suggested-action chips from the agent.</summary>
    public string? SuggestedActionsJson { get; set; }

    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;

    /// <summary>Set when the agent call failed, so the UI can show it differently.</summary>
    public bool IsError { get; set; }
}

/// <summary>Admin-editable setting. Secret values are stored encrypted.</summary>
public class AppSetting
{
    [Key]
    [MaxLength(200)]
    public string Key { get; set; } = "";

    public string? Value { get; set; }

    /// <summary>True when Value is Data Protection ciphertext.</summary>
    public bool IsSecret { get; set; }

    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;

    [MaxLength(200)]
    public string? UpdatedBy { get; set; }
}
