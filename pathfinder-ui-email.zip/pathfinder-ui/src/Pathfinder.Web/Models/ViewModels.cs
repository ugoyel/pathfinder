using Pathfinder.Web.Services;

namespace Pathfinder.Web.Models;

/// <summary>
/// Implemented by every page model that renders inside the app shell, so the layout can
/// find the rail data without knowing which page it is drawing.
/// </summary>
public interface IShellHost
{
    ShellViewModel Shell { get; }
}

/// <summary>Everything the shared shell (rail, conversation list, header) needs to render.</summary>
public class ShellViewModel : IShellHost
{
    ShellViewModel IShellHost.Shell => this;

    public BrandOptions Brand { get; set; } = new();
    public string UserName { get; set; } = "";
    public string UserEmail { get; set; } = "";
    public bool IsAdmin { get; set; }

    /// <summary>Name shown above the agent's replies, from Admin -> Agent.</summary>
    public string AgentName { get; set; } = "Pathfinder";

    /// <summary>Which rail item to highlight: "chat", "dashboard", "schema" or "admin".</summary>
    public string ActiveNav { get; set; } = "chat";

    /// <summary>False until an admin connects the Copilot agent. Drives the warning strip.</summary>
    public bool AgentConfigured { get; set; }

    /// <summary>True while the app is using the local sign-in rather than Okta.</summary>
    public bool UsingLocalSignIn { get; set; }
}

public class LoginViewModel
{
    public BrandOptions Brand { get; set; } = new();

    /// <summary>"Okta", "EntraId" or "DevBypass".</summary>
    public string Mode { get; set; } = "DevBypass";

    public string? ReturnUrl { get; set; }
    public string? Error { get; set; }

    public bool UsesSingleSignOn => !Mode.Equals("DevBypass", StringComparison.OrdinalIgnoreCase);

    public string ProviderName => Mode.Equals("EntraId", StringComparison.OrdinalIgnoreCase)
        ? "Microsoft"
        : "Moody's";
}

/// <summary>Usage figures for the signed-in person, shown on the Dashboard.</summary>
public class DashboardViewModel : IShellHost
{
    public ShellViewModel Shell { get; set; } = new();

    public int Conversations { get; set; }
    public int MessagesSent { get; set; }
    public int RepliesReceived { get; set; }
    public DateTime? LastActivityUtc { get; set; }

    public List<RecentItem> Recent { get; set; } = new();

    public record RecentItem(Guid Id, string Title, DateTime UpdatedUtc, int MessageCount);
}

/// <summary>The Admin page, one tab per section.</summary>
public class AdminViewModel : IShellHost
{
    public ShellViewModel Shell { get; set; } = new();
    public AgentOptions Agent { get; set; } = new();
    public MiddlewareOptions Middleware { get; set; } = new();
    public AuthOptions Auth { get; set; } = new();
    public BrandOptions Brand { get; set; } = new();

    /// <summary>The sign-in settings the running process actually started with.</summary>
    public string ActiveAuthMode { get; set; } = "DevBypass";

    /// <summary>True when Auth settings were saved but the app has not been restarted yet.</summary>
    public bool AuthRestartPending { get; set; }

    /// <summary>The redirect URI to register in Okta, worked out from the current request.</summary>
    public string ExpectedRedirectUri { get; set; } = "";
    public string ExpectedSignOutUri { get; set; } = "";

    public string? StatusMessage { get; set; }
    public bool StatusIsError { get; set; }
}
