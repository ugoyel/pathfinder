using System.Security.Claims;
using Pathfinder.Web.Services;

namespace Pathfinder.Web.Auth;

/// <summary>
/// Turns the claims an identity provider sent us into the small user record the rest of
/// the app works with. Okta, Entra ID and the local dev sign-in all spell these claims
/// slightly differently, so each value is looked up across the usual names.
/// </summary>
public sealed class UserContext
{
    private readonly IHttpContextAccessor _http;
    private readonly SettingsService _settings;

    public UserContext(IHttpContextAccessor http, SettingsService settings)
    {
        _http = http;
        _settings = settings;
    }

    public CurrentUser? Current
    {
        get
        {
            var principal = _http.HttpContext?.User;
            if (principal?.Identity?.IsAuthenticated != true) return null;
            return From(principal, _settings.Load<AuthOptions>(AuthOptions.Section));
        }
    }

    /// <summary>Throws when called outside an authenticated request. Controllers are [Authorize], so it will not be.</summary>
    public CurrentUser Require()
        => Current ?? throw new InvalidOperationException("No signed-in user on this request.");

    public static CurrentUser From(ClaimsPrincipal principal, AuthOptions auth)
    {
        var email = FirstClaim(principal,
            "email", ClaimTypes.Email, "preferred_username", "upn", "unique_name") ?? "";

        // "sub" is stable across email changes, which matters because it keys the chat history.
        var id = FirstClaim(principal, "sub", ClaimTypes.NameIdentifier, "oid")
                 ?? (email.Length > 0 ? email : "unknown");

        var name = FirstClaim(principal, "name", ClaimTypes.Name, "given_name")
                   ?? (email.Length > 0 ? email.Split('@')[0] : "User");

        return new CurrentUser(id, name, email, IsAdmin(principal, auth, email));
    }

    /// <summary>
    /// Admin access comes from either an explicit email list or a group claim. The dev
    /// sign-in mode grants it to everyone so a fresh install can be configured at all.
    /// </summary>
    public static bool IsAdmin(ClaimsPrincipal principal, AuthOptions auth, string email)
    {
        if (auth.Mode.Equals("DevBypass", StringComparison.OrdinalIgnoreCase)) return true;

        if (email.Length > 0 && SplitList(auth.AdminEmails)
                .Any(a => a.Equals(email, StringComparison.OrdinalIgnoreCase)))
        {
            return true;
        }

        var adminGroups = SplitList(auth.AdminGroups);
        if (adminGroups.Count == 0) return false;

        var claimType = string.IsNullOrWhiteSpace(auth.GroupsClaimType) ? "groups" : auth.GroupsClaimType;
        var memberships = principal.Claims
            .Where(c => c.Type.Equals(claimType, StringComparison.OrdinalIgnoreCase)
                        || c.Type == ClaimTypes.Role)
            .Select(c => c.Value);

        return memberships.Any(g => adminGroups.Any(a => a.Equals(g, StringComparison.OrdinalIgnoreCase)));
    }

    public static List<string> SplitList(string? csv)
        => string.IsNullOrWhiteSpace(csv)
            ? new List<string>()
            : csv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();

    private static string? FirstClaim(ClaimsPrincipal principal, params string[] types)
    {
        foreach (var type in types)
        {
            var value = principal.FindFirst(type)?.Value;
            if (!string.IsNullOrWhiteSpace(value)) return value;
        }
        return null;
    }
}
