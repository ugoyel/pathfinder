using Microsoft.AspNetCore.Authorization;
using Pathfinder.Web.Services;

namespace Pathfinder.Web.Auth;

/// <summary>Marks the "can open the Admin page" policy.</summary>
public sealed class AdminRequirement : IAuthorizationRequirement
{
    public const string PolicyName = "PathfinderAdmin";
}

/// <summary>
/// Decides admin access per request, reading the current admin list from settings rather
/// than from a value captured at startup - so adding an admin takes effect immediately.
/// </summary>
public sealed class AdminHandler : AuthorizationHandler<AdminRequirement>
{
    private readonly IServiceScopeFactory _scopes;

    public AdminHandler(IServiceScopeFactory scopes) => _scopes = scopes;

    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, AdminRequirement requirement)
    {
        if (context.User.Identity?.IsAuthenticated != true) return Task.CompletedTask;

        using var scope = _scopes.CreateScope();
        var settings = scope.ServiceProvider.GetRequiredService<SettingsService>();
        var auth = settings.Load<AuthOptions>(AuthOptions.Section);

        var user = UserContext.From(context.User, auth);
        if (user.IsAdmin) context.Succeed(requirement);

        return Task.CompletedTask;
    }
}
