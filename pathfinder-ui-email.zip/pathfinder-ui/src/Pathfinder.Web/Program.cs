using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Pathfinder.Web.Auth;
using Pathfinder.Web.Data;
using Pathfinder.Web.Services;

var builder = WebApplication.CreateBuilder(args);

// Where the database and the encryption key ring live.
var dataDirectory = Bootstrap.DataDirectory(builder.Configuration, builder.Environment.ContentRootPath);

// Sign-in settings have to be read before the web host exists, because the OpenID
// Connect handler is configured once, at registration time.
using var startupLoggers = LoggerFactory.Create(logging => logging.AddConsole());
var auth = Bootstrap.LoadStartupAuth(builder.Configuration, dataDirectory, startupLoggers);
var startupLog = startupLoggers.CreateLogger("Pathfinder.Startup");

// An incomplete Okta configuration must not leave the app unable to start: the admin
// would have no way back in to fix it. Fall back to the local sign-in and say so loudly.
var wantsOidc = auth.Mode.Equals("Okta", StringComparison.OrdinalIgnoreCase)
             || auth.Mode.Equals("EntraId", StringComparison.OrdinalIgnoreCase);

if (wantsOidc && (string.IsNullOrWhiteSpace(auth.Authority) || string.IsNullOrWhiteSpace(auth.ClientId)))
{
    startupLog.LogWarning(
        "Auth:Mode is {Mode} but the authority or client id is blank, so single sign-on cannot be set up. " +
        "Starting with the local sign-in instead. Fill these in on the Admin page, then restart.",
        auth.Mode);
    wantsOidc = false;
    auth.Mode = "DevBypass";
}

// ---------------------------------------------------------------- services

builder.Services.AddSingleton(auth);
builder.Services.AddSingleton<SettingsCache>();
builder.Services.AddSingleton<AgentHttpClientProvider>();
builder.Services.AddSingleton<ISecretProtector, SecretProtector>();
builder.Services.AddSingleton<IAuthorizationHandler, AdminHandler>();

Bootstrap.AddDatabase(builder.Services, builder.Configuration, dataDirectory);
Bootstrap.AddKeyRing(builder.Services, dataDirectory);

builder.Services.AddScoped<SettingsService>();
builder.Services.AddScoped<CopilotClient>();
builder.Services.AddScoped<ConversationService>();
builder.Services.AddScoped<UserContext>();
builder.Services.AddScoped<ShellFactory>();
builder.Services.AddHttpContextAccessor();

// Every non-GET request must carry an antiforgery token, which the chat page sends as a
// header. Together with a SameSite cookie this covers cross-site request forgery.
builder.Services.AddControllersWithViews(options =>
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));
builder.Services.AddAntiforgery(options => options.HeaderName = "RequestVerificationToken");

builder.Services.AddAuthorization(options =>
    options.AddPolicy(AdminRequirement.PolicyName, policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.Requirements.Add(new AdminRequirement());
    }));

// Azure Container Apps and most load balancers terminate TLS and forward the original
// scheme. Without this the sign-in redirect would be built as http and Okta would reject it.
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor
                             | ForwardedHeaders.XForwardedProto
                             | ForwardedHeaders.XForwardedHost;
    options.KnownNetworks.Clear();
    options.KnownProxies.Clear();
});

var authentication = builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = wantsOidc
        ? OpenIdConnectDefaults.AuthenticationScheme
        : CookieAuthenticationDefaults.AuthenticationScheme;
})
.AddCookie(options =>
{
    options.Cookie.Name = "Pathfinder.Auth";
    options.Cookie.HttpOnly = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    options.ExpireTimeSpan = TimeSpan.FromHours(Math.Clamp(auth.SessionHours, 1, 24 * 14));
    options.SlidingExpiration = true;
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/Denied";
    options.ReturnUrlParameter = "returnUrl";
});

if (wantsOidc)
{
    authentication.AddOpenIdConnect(OpenIdConnectDefaults.AuthenticationScheme, options =>
    {
        options.Authority = auth.Authority.TrimEnd('/');
        options.ClientId = auth.ClientId;
        if (!string.IsNullOrWhiteSpace(auth.ClientSecret)) options.ClientSecret = auth.ClientSecret;

        options.ResponseType = OpenIdConnectResponseType.Code;
        options.UsePkce = auth.UsePkce;
        options.RequireHttpsMetadata = auth.RequireHttpsMetadata;

        options.CallbackPath = new PathString(NormalisePath(auth.CallbackPath, "/authorization-code/callback"));
        options.SignedOutCallbackPath = new PathString(NormalisePath(auth.SignedOutCallbackPath, "/signout-callback-oidc"));
        options.SignedOutRedirectUri = "/";

        // Okta returns groups and a full profile from the userinfo endpoint rather than
        // always packing them into the id token.
        options.GetClaimsFromUserInfoEndpoint = true;
        options.SaveTokens = false;

        // Keep the original claim names ("sub", "email", "groups") instead of the long
        // WS-Federation URIs, so the lookups in UserContext read plainly.
        options.MapInboundClaims = false;

        options.Scope.Clear();
        foreach (var scope in (auth.Scopes ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            options.Scope.Add(scope);
        if (options.Scope.Count == 0) options.Scope.Add("openid");

        options.TokenValidationParameters = new TokenValidationParameters
        {
            NameClaimType = "name",
            RoleClaimType = string.IsNullOrWhiteSpace(auth.GroupsClaimType) ? "groups" : auth.GroupsClaimType,
        };

        options.Events = new OpenIdConnectEvents
        {
            // Without this, a rejected sign-in shows a bare exception page. Send the
            // person back to the branded login screen with something readable instead.
            OnRemoteFailure = context =>
            {
                var reason = context.Failure?.Message ?? "Sign-in did not complete.";
                context.Response.Redirect("/Account/Login?error=" + Uri.EscapeDataString(reason));
                context.HandleResponse();
                return Task.CompletedTask;
            },
        };
    });
}

// ---------------------------------------------------------------- pipeline

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
}

app.UseForwardedHeaders();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

if (builder.Configuration.GetValue("Security:HttpsRedirection", true))
    app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");

// Container platforms poll this to decide whether the revision is healthy.
app.MapGet("/healthz", () => Results.Ok(new { status = "ok", utc = DateTime.UtcNow }))
   .AllowAnonymous();

app.Run();

// Accepts "authorization-code/callback" or "/authorization-code/callback" and returns the
// leading-slash form that PathString requires.
static string NormalisePath(string? value, string fallback)
{
    if (string.IsNullOrWhiteSpace(value)) return fallback;
    var trimmed = value.Trim();
    return trimmed.StartsWith('/') ? trimmed : "/" + trimmed;
}
